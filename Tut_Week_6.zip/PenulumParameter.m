
%% parameter values for pendulum_2022 simulink
clear all; clc
m = 0.2;
M =5;
L = 1;
J = 0.006;
g = 10;
Fc = 0.01;
Fp=0;
d = 0;  
sInit =0;
phiInit = 0.5;

