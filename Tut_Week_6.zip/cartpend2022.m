function dy = cartpend2022(y,m,M,L,J,g,Fp,Fc,u)

Sy = sin(y(3));
Cy = cos(y(3));
D = (M+m)*(J+m*L^2) - m^2*L^2*Cy^2;

dy(1,1) = y(2);
dy(2,1) = (1/D)*((J+m*L^2)*(u-Fc*y(2)+m*L*Sy*y(4)^2) - m^2*L^2*Cy*Sy*g+m*L*Cy*Fp*y(4));
dy(3,1) = y(4);
dy(4,1) = (1/D)*(-m*L*Cy*u-m^2*L^2*y(4)^2*Sy*Cy+Fc*m*L*Cy*y(2)-Fp*(M+m)*y(4)+m*g*L*(M+m)*Sy);