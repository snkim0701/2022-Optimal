clear all, close all, clc
LW = 'linewidth';
m = 0.2;     % pendulum  mass
M = 5;       % cart mass
L = 1;         % length of Pend.
J = 0.006;    % inertia of Pend.
g = 10;       % gravity
Fc = 0.01;    % viscosity of cart
Fp=0;         % viscosity of Pend.
d = 0;        % disturbance input
sInit =0;     % initial of the cart position
phiInit = 0.5;   % initial of the Pend angle

tspan = 0:.001:10;   
y0 = [sInit; 0; phiInit; 0];

[t,yNL] = ode45(@(t,y)cartpend2022(y,m,M,L,J,g,Fp,Fc,0),tspan,y0);

figure(1)
plot(t,yNL(:,1), LW,2); grid on
figure(2)
plot(t,yNL(:,3), LW,2); grid on

figure
for k=1:100:length(t)
    drawcartpend_2022(yNL(k,:),m,M,L);
end